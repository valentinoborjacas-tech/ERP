# SGA-Almacén — Módulo 1: Stock

Estructura del proyecto:

```
index.html            → shell de la app (cabecera + sidebar + contenedor de módulos)
assets/style.css       → diseño visual (todo el CSS de escritorio clásico)
assets/config.js       → aquí pegas la URL de tu Apps Script
assets/app.js          → navegación del sidebar y carga dinámica de módulos
modules/stock.html     → HTML del módulo Stock (se inyecta en index.html)
modules/stock.js       → lógica del módulo Stock (llama al Apps Script)
apps-script/Code.gs    → backend (esto NO va en GitHub, va en Google Apps Script)
```

Cuando construyas el módulo Artículos, Ubicaciones o Historial, cada uno seguirá
el mismo patrón: `modules/<nombre>.html` + `modules/<nombre>.js`, y agregar
`'<nombre>'` al arreglo `builtModules` en `assets/app.js`.

## Paso 1 — Prepara el Google Sheet

Crea (o reordena) tu hoja con estas 3 pestañas y columnas exactas
(los encabezados deben coincidir, Apps Script los lee por nombre):

- **ARTICULOS**: `ID, DESCRIPCIÓN, LITRAJE, COLOR, ANCHO, LARGO, ESPESOR, PRESENTACIÓN, STOCK_MINIMO, STOCK_MAXIMO, ESTADO`
- **UBICACION**: `ID_UBICACIÓN, ID_FILA, MODULO, LADO, NIVEL, ID_ARTICULO, STOCK_DISPONIBLE, ULTIMA_ACTUALIZACIÓN`
- **MOVIMIENTOS**: `FECHA/HORA, ID, ID_UBICACIÓN, TIPO, CANTIDAD, MOTIVO, USUARIO`

> Nota: usa `STOCK_MINIMO` / `STOCK_MAXIMO` sin tilde como nombre de columna
> (así están referenciados en el código). Si prefieres con tilde, ajusta esa
> línea en `Code.gs`.

## Paso 2 — Despliega el Apps Script

1. En tu Sheet: **Extensiones > Apps Script**.
2. Pega el contenido de `apps-script/Code.gs`.
3. Reemplaza `SHEET_ID` por el ID de tu hoja (está en la URL, entre `/d/` y `/edit`).
4. **Implementar > Nueva implementación > Tipo: Aplicación web.**
   - Ejecutar como: **Yo**
   - Quién tiene acceso: **Cualquier usuario**
5. Copia la URL que termina en `/exec`.

## Paso 3 — Conecta el frontend

Abre `assets/config.js` y pega esa URL:

```js
const API_URL = 'https://script.google.com/macros/s/AKfycb.../exec';
```

## Paso 4 — Publica en GitHub Pages

1. Sube toda la carpeta del proyecto (menos `apps-script/`, eso solo vive en Google) a tu repositorio.
2. En el repo: **Settings > Pages > Deploy from branch**, elige la rama y carpeta raíz (`/`).
3. Entra a la URL que te da GitHub Pages — el módulo Stock debería cargar datos reales desde tu Sheet.

## Cómo se conectan las piezas

```
index.html
   └─ carga assets/style.css (diseño)
   └─ carga assets/config.js (URL del backend)
   └─ carga modules/stock.js (funciones del módulo, no se ejecutan aún)
   └─ carga assets/app.js
         └─ hace fetch('modules/stock.html') e inyecta el HTML en #main-content
         └─ llama a window.initStockModule()
               └─ fetch(API_URL + '?action=stock')  → GET, trae el listado
               └─ fetch(API_URL, { method:'POST', body:... }) → registra ingreso/venta
                     └─ Apps Script actualiza MOVIMIENTOS y UBICACION en el Sheet
```

## Notas sobre CORS

El `fetch` de `stock.js` envía el `POST` sin `Content-Type` manual (solo
`body: JSON.stringify(...)`). Esto lo convierte en una "solicitud simple" que
el navegador no bloquea por CORS al llamar a Apps Script. Si en el futuro
agregas headers personalizados al fetch, es probable que tengas que manejar
`doOptions` en el `Code.gs` también.
